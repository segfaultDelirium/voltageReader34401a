import matplotlib.pyplot as plt

iArray = []
fpgaVoltageArray = []
sensorVoltageArray = []

with open("results.txt", mode="r", encoding='utf-8') as f:
    lines = f.readlines()
    for line in lines:
        print(line)
        splits = line.split(';')
        iArray.append(int(splits[0]))
        fpgaVoltageArray.append(float(splits[1]))
        sensorVoltageArray.append(float(splits[2]))
        

print(iArray)
print(fpgaVoltageArray)
print(sensorVoltageArray)
plt.scatter(iArray, fpgaVoltageArray)
plt.scatter(iArray, sensorVoltageArray)
plt.savefig("Wykres.png");
plt.show()
