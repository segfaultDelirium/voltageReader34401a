# to run the program: sudo python3 <filename>

# Enable pyserial extensions
import pyftdi.serialext
from numpy import arange
import time
import readVoltageLib

debug = False

minVoltage = 0.0
maxVoltage = 2.5

def writeToFPGA(port, bytesArray, debug=False):
    if debug:
        pass
        #print('pretend to write to fpga...')
    else:
        port.write(bytesArray)

def readFromFPGA(port, amount, debug=False, expectedData='debug expected data'):
    if debug:
        return expectedData
    return port.read(amount)

def readFromSensor(port, debug=False, expectedData='debug expected data'):
    if debug:
        return expectedData
    return readVoltageLib.readAverageVoltage(port)

def getPort(url, debug, **kwargs):
    print(f'getPort args: {kwargs}')
    if debug:
        return 'debug_port'
    return pyftdi.serialext.serial_for_url(url=url, **kwargs)

def voltageToBytesArray(voltage):
    voltageInDAC_resulution = int((voltage/maxVoltage) * DAC_resolution)
    data = voltageInDAC_resulution.to_bytes(2, 'little')
    first_byte = voltageInDAC_resulution.to_bytes(2, 'little')[1]
    second_byte =  voltageInDAC_resulution.to_bytes(2, 'little')[0]
    print(f'data', data)
    return bytes([first_byte, second_byte])


fpgaUrl = 'ftdi://ftdi:232:AQ00RVND/1' # to check the url, run the script `sudo python3 ftdi_urls.py`
sensorUrl = 'ftdi://ftdi:232:FT4T6R2Q/1'
# Open a serial port on the second FTDI device interface (IF/2) @ 3Mbaud
# available baud rates: 230400, 115200, 9600, 230400
fpgaPort = getPort(url=fpgaUrl, debug=debug, baudrate=230400, bytesize=8, stopbits=1, parity='N', xonxoff=False, rtscts=False)
voltageReaderPort = getPort(url=sensorUrl, debug=debug, baudrate=9600, timeout=10, bytesize=8, stopbits=2, parity='N')#, xonxoff=False, rtscts=False, dsrdtr=True)
if not debug:
    readVoltageLib.initial(voltageReaderPort)


voltageStep = 2.5/4095;
DAC_resolution = 2**12 -1 #4095

fpgaVoltagesArray = []
sensedVoltageArray = []
for voltage in arange(minVoltage, maxVoltage + voltageStep, voltageStep):
    voltageBitsArray = voltageToBytesArray(voltage)
    print(f'{voltage}\t {voltageBitsArray}')
    writeToFPGA(fpgaPort, voltageBitsArray, debug)
    time.sleep(0.1)
    fpgaVoltage = voltage
    fpgaVoltagesArray.append(fpgaVoltage)
    #fpgaVoltage = readFromFPGA(fpgaPort, len(voltageBitsArray), debug, expectedData=voltage)
    print(f'fpgaVoltage ={fpgaVoltage}')
    time.sleep(0.1)
    sensedVoltage = readFromSensor(voltageReaderPort, debug, voltage);
    sensedVoltageArray.append(sensedVoltage)
    print(f'sensedVoltage ={sensedVoltage}')

with open("results.txt", mode='w', encoding = 'utf-8') as f:
    for i in range(len(fpgaVoltagesArray)):
        f.write(f'{i};{fpgaVoltagesArray[i]};{sensedVoltageArray[i]}\n')
    

